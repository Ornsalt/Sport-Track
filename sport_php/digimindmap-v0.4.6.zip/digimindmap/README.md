# Digimindmap

Digimindmap est une application en ligne pour créer des cartes heuristiques simples. Elle est basée sur une version personnalisée et allégée de la librairie js My Mind (https://github.com/ondras/my-mind - MIT).

Digimindmap est publiée sous licence GNU GPLv3.
Sauf la fonte Material Icons, Robot Slab (Apache License Version 2.0) et la fonte HKGrotesk (Sil Open Font Licence 1.1)

### Préparation et installation des dépendances
```
npm install
```

### Lancement du serveur de développement
```
npm run serve
```

### Compilation et minification des fichiers
```
npm run build
```

### Serveur PHP nécessaire pour consommer l'API
```
php -S 127.0.0.1:8000 (pour le développement uniquement)
```

### Production
Le dossier dist peut être déployé directement sur un serveur PHP avec l'extension SQLite activée.

### Démo
https://ladigitale.dev/digimindmap/

### Soutien
https://opencollective.com/ladigitale

