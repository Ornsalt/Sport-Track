# Digiwords

Digiwords est une application en ligne simple pour créer des nuages de mots. 

Elle est publiée sous licence GNU GPLv3.
Sauf les fontes Abril Fat Face, Anton, Bahiana, Barrio, Finger Paint, Fredericka The Great, Gloria Hallelujah, Indie Flower, Life Savers, Londrina Sketch, Love Ya Like A Sister, Material Icons, Merienda, Pacifico, Quicksand, Righteous, Roboto et Robot Slab (Apache License Version 2.0), la fonte HKGrotesk et la fonte OpenDyslexic (Sil Open Font Licence 1.1)

### Préparation et installation des dépendances
```
npm install
```

### Lancement du serveur de développement
```
npm run serve
```

### Compilation et minification des fichiers
```
npm run build
```

### Serveur PHP nécessaire pour consommer l'API
```
php -S 127.0.0.1:8000 (pour le développement uniquement)
```

### Production
Le dossier dist peut être déployé directement sur un serveur PHP avec l'extension SQLite activée.

### Démo
https://ladigitale.dev/digiwords/

### Soutien
https://opencollective.com/ladigitale

